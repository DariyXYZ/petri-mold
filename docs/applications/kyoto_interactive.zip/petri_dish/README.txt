Instructions

Runs offline. No installation, no server, no login.

1. Interactive version: open index.html in Chrome or Edge.
   Pick a strain (or Random), click inside the Petri dish to place spores,
   press GROW. PAUSE stops growth, BURN clears the dish, PNG saves an image.
2. Autonomous version for exhibition: open auto/index.html.
   It runs on its own with no interface: spores are placed automatically,
   the colonies grow, the dish is burned and a new experiment begins.
   Press F11 for full screen.

Sound: click once anywhere to enable audio (browser policy),
or start Chrome with --autoplay-policy=no-user-gesture-required.

